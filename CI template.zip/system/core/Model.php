<?php
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2014 - 2018, British Columbia Institute of Technology
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	CodeIgniter
 * @author	EllisLab Dev Team
 * @copyright	Copyright (c) 2008 - 2014, EllisLab, Inc. (https://ellislab.com/)
 * @copyright	Copyright (c) 2014 - 2018, British Columbia Institute of Technology (http://bcit.ca/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	https://codeigniter.com
 * @since	Version 1.0.0
 * @filesource
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Model Class
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Libraries
 * @author		EllisLab Dev Team
 * @link		https://codeigniter.com/user_guide/libraries/config.html
 */
class CI_Model {

	/**
	 * Class constructor
	 *
	 * @link	https://github.com/bcit-ci/CodeIgniter/issues/5332
	 * @return	void
	 */
	public function __construct() {}

	/**
	 * __get magic
	 *
	 * Allows models to access CI's loaded classes using the same
	 * syntax as controllers.
	 *
	 * @param	string	$key
	 */
	public function __get($key)
	{
		// Debugging note:
		//	If you're here because you're getting an error message
		//	saying 'Undefined Property: system/core/Model.php', it's
		//	most likely a typo in your model code.
		return get_instance()->$key;
	}


	/*-======================= CUSTOM FUNCTIONS ===========================*/


	function save_record($tbl, $dataArray=array(), $updateCond = "")
    {
		//echo "<pre>"; print_r($dataArray); echo "</pre>"; exit;
		
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Add Created / Modified column ~~~~~~~~~~~~~~~~~~
		if(isset($dataArray['id']))	{
			if($dataArray['id'] != '')	{
				$dataArray['modified'] = date("Y-m-d H:i:s");
			}else	{
				$dataArray['created'] = date("Y-m-d H:i:s");
				$dataArray['modified'] = "0000-00-00 00:00:00";
			}
		}
        else	{
			$dataArray['created'] = date("Y-m-d H:i:s");
		}
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Add Created / Modified column ~~~~~~~~~~~~~~~~~~

		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ delete unnessery column ~~~~~~~~~~~~~~~~~~
		$colArray 	= $this->db->query("DESC `".$tbl.'`'); 
		$cols 		= array();
		
		foreach($colArray->result() as $col)	{
			array_push($cols, $col->Field);
		}
		
		foreach($dataArray as $key => $val)	{
			if(!in_array($key, $cols))	{
				unset($dataArray[$key]);
			}
		}


		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ delete unnessery column ~~~~~~~~~~~~~~~~~~
		
		if(isset($dataArray['id']))	{
			if($dataArray['id'] != '')	{

				if($this->findById_record($tbl, $dataArray['id'])){
					$this->db->where('id',$dataArray['id']);
					$this->db->update($tbl, $dataArray);
					return $dataArray['id'];
				}else{
					return FALSE;
				}
			}
			else{
				$this->db->insert($tbl, $dataArray);
				return $this->db->insert_id();
			}
		} elseif($updateCond != ""){
			$this->db->where($updateCond);
			$this->db->update($tbl, $dataArray);
			return TRUE;
		}
        else	{
            $this->db->insert($tbl, $dataArray);
            return $this->db->insert_id();
		}
        //echo $this->db->last_query(); exit(0);
    }

    function update_record($tbl, $clause='',$dataArray=array())
    {
		//echo "<pre>"; print_r($dataArray); echo "</pre>"; exit;
		
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Add Created / Modified column ~~~~~~~~~~~~~~~~~~
		if(isset($dataArray['id']))	{
			if($dataArray['id'] != '')	{
				$dataArray['modified'] = date("Y-m-d H:i:s");
			}else	{
				//$dataArray['modified_on'] = date("Y-m-d H:i:s");
				$dataArray['modified'] = "0000-00-00 00:00:00";
			}
		}
        else	{
			$dataArray['modified'] = date("Y-m-d H:i:s");
		}
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Add Created / Modified column ~~~~~~~~~~~~~~~~~~

		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ delete unnessery column ~~~~~~~~~~~~~~~~~~
		$colArray 	= $this->db->query("DESC `".$tbl.'`'); 
		$cols 		= array();
		
		foreach($colArray->result() as $col)	{
			array_push($cols, $col->Field);
		}
		
		foreach($dataArray as $key => $val)	{
			if(!in_array($key, $cols))	{
				unset($dataArray[$key]);
			}
		}
		if($clause!='')
		{
			$this->db->where($clause);
			$this->db->update($tbl, $dataArray);
			return true;
		}
		return false;

    }
	
	function find_record($tbl, $fields, $join =array(), $extra='', $order = '', $group = '', $limit = '')
    {
		$this->db->select($fields);											// Select column
        $this->db->from($tbl);												// From Table
        
		if(!empty($join))
			foreach($join as $eachVal)	{
				$this->db->join($eachVal['table'].' '.$eachVal['alias'], $eachVal['conditions'], $eachVal['type']);
			}
		$tableName = explode(' ', $tbl);

		$tblForAl = (@$tableName[1] != "") ? $tableName[1] : $tableName[0];
		$this->db->where($tblForAl.".status != 'inactive'");									// No deleted record should be display
        if($extra != '') $this->db->where($extra);							// Where conditions
		if($order != '') $this->db->order_by($order);						// Order by
		if($group != '') $this->db->group_by($group);						// Group by
		
		if($limit)	{														// Limit
			$limitOfset = explode(',', $limit); 
			if(count($limitOfset) == 2)
				$this->db->limit($limitOfset[1],$limitOfset[0]);
			else
				$this->db->limit($limit);
		}
        
        $query = $this->db->get();
        
        //echo $this->db->last_query(); //exit(0);
        
		//echo "<pre>"; print_r($query->result_array()); echo "</pre>"; //exit;
		
        if($query->num_rows() > 0)
            return $query->result_array();
        else
            return [];
    }
	
	function find_all_record($tbl, $fields, $join =array(), $extra='', $order = '', $group = '', $limit = '')
    {
		$this->db->select($fields);											// Select column
        $this->db->from($tbl);												// From Table
        
		if(!empty($join))
			foreach($join as $eachVal)	{
				$this->db->join($eachVal['table'].' '.$eachVal['alias'], $eachVal['conditions'], $eachVal['type']);
			}
		$tableName = explode(' ', $tbl);
			
        if($extra != '') $this->db->where($extra);							// Where conditions
		if($order != '') $this->db->order_by($order);						// Order by
		if($group != '') $this->db->group_by($group);						// Group by
		
		if($limit)	{														// Limit
			$limitOfset = explode(',', $limit); 
			if(count($limitOfset) == 2)
				$this->db->limit($limitOfset[1],$limitOfset[0]);
			else
				$this->db->limit($limit);
		}
        
        $query = $this->db->get();
        
        //echo $this->db->last_query(); //exit(0);
        
		//echo "<pre>"; print_r($query->result_array()); echo "</pre>"; //exit;
		
        if($query->num_rows() > 0)
            return $query->result_array();
        else
            return [];
    }
	
	function findById_record($tbl, $id)	{
		
		$this->db->where('id',"{$id}");
		$query = $this->db->get($tbl);
		//echo $this->db->last_query();
		
		if($query->num_rows() > 0)
			return $query->row_array();
		else
			return [];
	}
	
	function findBy_record($tbl, $field, $value, $order = '')	{
		
		$this->db->where($field, $value);
		if($order != '') $this->db->order_by($order);				// optional order
		$query = $this->db->get($tbl);
		//echo $this->db->last_query();
		
		if($query->num_rows() > 0)
			return $query->row_array();
		else
			return [];
	}
	
	function delete_record($tbl,$id)	{
		
		$this->db->where('id',$id);
		return $this->db->update($tbl, ['status' => 'D']);
		//return $query = $this->db->delete($tbl);
	}

	function delete_recordbyid($tbl,$id)	{
		return $query = $this->db->delete($tbl,array('id' => $id));
	}
	
	function deleteAll_record($tbl,$condition = '')	{
		
		if($condition)	{
			$this->db->where($condition);
			//return $query = $this->db->delete($tbl);
			return $this->db->update($tbl, ['status' => 'D']);
		}
		else
			return NULL;
		//echo $this->db->last_query();
	}

}
