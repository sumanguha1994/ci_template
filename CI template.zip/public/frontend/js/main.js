/* my code */

var $gallery = $('.single-item');
var slideCount = null;

$( document ).ready(function() {
    $gallery.slick({
      autoplay: true,
      adaptiveHeight: true,
      speed: 250,
      fade: true,
      cssEase: 'linear',
      swipe: true,
      swipeToSlide: true,
      touchThreshold: 10
    });
});

$gallery.on('init', function(event, slick){
  slideCount = slick.slideCount;
  setSlideCount();
  setCurrentSlideNumber(slick.currentSlide);
});

$gallery.on('beforeChange', function(event, slick, currentSlide, nextSlide){
  setCurrentSlideNumber(nextSlide);
});

function setSlideCount() {
  var $el = $('.slide-count-wrap').find('.total');
  $el.text(slideCount);
}

function setCurrentSlideNumber(currentSlide) {
  var $el = $('.slide-count-wrap').find('.current');
  $el.text(currentSlide + 1);
}

